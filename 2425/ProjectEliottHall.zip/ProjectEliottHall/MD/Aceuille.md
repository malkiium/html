## Le monde magique

### Découvrez les secrets de Poudlard et au-delà

Ce site vous propose une immersion dans l’univers d’Harry Potter.

Avec des informations sur les personnages emblématiques, les lieux incontournables, les objets magiques et bien plus encore.

### À propos de ce site

Ce projet a été réalisé dans le cadre du cours d'Informatique et documents.

Il est composé de cinq pages, toutes respectant une structure commune et générées avec Pandoc à partir de fichiers Markdown.

---

**Réalisé par HALL Eliott **
