## Les maisons de Poudlard

### Répartition des élèves

Chaque maison représente une qualité centrale : courage, ruse, sagesse, loyauté...

### Liste des maisons

- **Gryffondor** – Bravoure et héroïsme
- **Serpentard** – Ambition et ruse
- **Serdaigle** – Intelligence et érudition
- **Poufsouffle** – Patience et loyauté
