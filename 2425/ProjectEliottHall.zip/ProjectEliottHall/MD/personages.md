## Les Personnages d'Harry Potter

### Explorez les héros et les vilains du monde magique

Découvrez les personnages les plus emblématiques de l'univers d'Harry Potter. Que ce soit le courageux Harry, l'intelligente Hermione, ou le fidèle Ron, chaque personnage a sa place dans cette saga magique.

#### Harry, Ron et Hermione - Les meilleurs amis de Poudlard

### Les personnages importants

Parmi les autres personnages majeurs, on retrouve des figures comme Albus Dumbledore, Severus Snape, et le mystérieux Sirius Black. Chacun d'eux joue un rôle crucial dans l'histoire de Harry Potter.

### Les antagonistes

Le plus grand antagoniste de la saga est bien sûr Lord Voldemort, mais il n'est pas seul. Des personnages comme Bellatrix Lestrange, Lucius Malfoy et les Mangemorts complètent cette partie sombre du monde magique.

### Liste des personnages

- [Harry Potter](https://fr.wikipedia.org/wiki/Harry_Potter_(personnage))
- [Hermione Granger](https://fr.wikipedia.org/wiki/Hermione_Granger)
- [Ron Weasley](https://fr.wikipedia.org/wiki/Ron_Weasley)
- [Albus Dumbledore](https://fr.wikipedia.org/wiki/Albus_Dumbledore)
- [Severus Snape](https://fr.wikipedia.org/wiki/Severus_Rogue)
- [Voldemort](https://fr.wikipedia.org/wiki/Voldemort)
- [Bellatrix Lestrange](https://fr.wikipedia.org/wiki/Bellatrix_Lestrange)
- [Sirius Black](https://fr.wikipedia.org/wiki/Sirius_Black)
- [Draco Malfoy](https://fr.wikipedia.org/wiki/Drago_Malefoy)
